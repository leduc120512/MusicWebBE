package com.musicapi.repository;

import com.musicapi.model.Like;
import com.musicapi.model.Song;
import com.musicapi.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LikeRepository extends JpaRepository<Like, Long> {
    Optional<Like> findByUserAndSong(User user, Song song);
    boolean existsByUserAndSong(User user, Song song);
    
    @Query("SELECT l.song FROM Like l WHERE l.user = :user ORDER BY l.createdAt DESC")
    Page<Song> findLikedSongsByUser(@Param("user") User user, Pageable pageable);
    
    @Query("SELECT COUNT(l) FROM Like l WHERE l.song = :song")
    Long countLikesBySong(@Param("song") Song song);
}
